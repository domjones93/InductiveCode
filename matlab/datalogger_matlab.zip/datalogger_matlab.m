% MATLAB datalogger that mimics the Python pipeline (read -> batch/process -> save)
% Uses a single high-rate timer which accumulates a batch, runs prediction when
% the batch is full and appends formatted lines to a CSV file.
close all
clear
% Configuration
serialPort = 'COM4';        % <-- change to your port (e.g. 'COM4')
samplePeriod = 0.01;       % seconds between reads (0.01 = 100 Hz sample request NOT ACTUAL RATE!)
durationSeconds = 5;      % total run time in seconds (set to Inf for continuous)
BATCH_SIZE = 10;           % number of samples per batch for prediction

% Resolve paths (place logfile next to Sensor.m)
sensorPath = which('Sensor');
if isempty(sensorPath)
    error('Sensor.m not found on the MATLAB path. Add its folder to path before running.');
end
baseDir = fileparts(sensorPath);
logfile = fullfile(baseDir, sprintf('sensor_data_%s.csv', datestr(now,'yyyymmdd_HHMMSS')));

% Load NNet
load('net.mat','net')
% nn_wb = load("nn_weights.mat");
% net2 = formwb(net,b,iw,lw)%load('calib2.mat');
% genFunction(net.Network,'myNeuralNetworkFunction2');
   

% Create sensor object and ensure connection
sensor = Sensor(serialPort);
try
    sensor.connect();
catch
    warning('sensor.connect() raised an error; attempting to continue.');
end

% Prepare logfile and write header
fid = fopen(logfile, 'w');
if fid == -1
    error('Unable to create logfile: %s', logfile);
end
fprintf(fid, 'timestamp,L0,L1,L2,L3,dX,dY,dZ\n');
fclose(fid);

% Shared mutable state (containers.Map is a handle-like container that callbacks can modify)
state = containers.Map();
state('sensor') = sensor;
state('batch') = {};
state('timestamps') = {};
state('BATCH_SIZE') = BATCH_SIZE;
state('logfile') = logfile;
state('fid') = fid; % unused here but kept for reference

% Create and start a timer that reads sensor and processes batches
t = timer('ExecutionMode','fixedSpacing', 'Period', samplePeriod, ...
          'TimerFcn', {@timerTick, state});
start(t);
fprintf('Recording started. Logging to: %s\n', logfile);

% Wait for duration and then clean up
if isfinite(durationSeconds)
    pause(durationSeconds);
    stop(t);
    delete(t);
    % After stopping timer, make sure any remaining batch is processed and saved
    flushRemainingBatch(state);
    try
        sensor.disconnect();
    catch
    end
    fprintf('Recording finished. File saved to: %s\n', logfile);
else
    fprintf('Recording running indefinitely. Use stop(t); delete(t); to stop and flush.\n');
end

% ---------- Local helper functions ----------
function timerTick(~, ~, st)
    % One timer tick: read one measurement and append to batch. If batch full,
    % run prediction and append results to file.
    s = st('sensor');
    try
        [timestamp, ~, L0, L1, L2, L3] = s.process_single_measurement();
    catch
        % read failed; skip this tick
        return;
    end

    % Append to batch
    batch = st('batch');
    tlist = st('timestamps');
    batch{end+1,1} = [L0, L1, L2, L3];
    tlist{end+1,1} = timestamp;
    st('batch') = batch;
    st('timestamps') = tlist;

    % If batch reached target size, process it
    if numel(batch) >= st('BATCH_SIZE')
        % Prepare raw array
        rawArray = cell2mat(batch); % (N x 4)
        % Predict positions if model available
        predictions = CivilCalibFunction(rawArray'); % default 3 dims if no model

        % Append lines to file
        fidw = fopen(st('logfile'), 'a');
        if fidw == -1
            warning('Failed to open logfile for append: %s', st('logfile'));
        else
            for k = 1:size(rawArray,1)
                ts = tlist{k};
                % if isa(ts, 'datetime')
                %     tsStr = datestr(ts, 'yyyy-mm-dd HH:MM:SS.FFF');
                % else
                %     tsStr = datestr(now, 'yyyy-mm-dd HH:MM:SS.FFF');
                % end
                raw = rawArray(k,:);
                pred = predictions(:,k)';
                % Ensure pred has 3 columns for dX,dY,dZ; otherwise pad/truncate
                if numel(pred) < 3
                    pred = [pred, nan(1,3-numel(pred))];
                elseif numel(pred) > 3
                    pred = pred(1:3);
                end
                fprintf(fidw, '%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n', ...
                    ts, raw(1), raw(2), raw(3), raw(4), pred(1), pred(2), pred(3));
            end
            fclose(fidw);
        end

        % Clear batch
        st('batch') = {};
        st('timestamps') = {};
    end
end

function flushRemainingBatch(st)
    batch = st('batch');
    tlist = st('timestamps');
    if isempty(batch)
        return;
    end
    rawArray = cell2mat(batch);
    s = st('sensor');
    try
        if ~isempty(s.model)
            predictions = s.predict_position(rawArray);
        else
            predictions = NaN(size(rawArray,1), 3);
        end
    catch
        predictions = NaN(size(rawArray,1), 3);
    end
    fidw = fopen(st('logfile'), 'a');
    if fidw ~= -1
        for k = 1:size(rawArray,1)
            ts = tlist{k};
            if isa(ts, 'datetime')
                tsStr = datestr(ts, 'yyyy-mm-dd HH:MM:SS.FFF');
            else
                tsStr = datestr(now, 'yyyy-mm-dd HH:MM:SS.FFF');
            end
            raw = rawArray(k,:);
            pred = predictions(k,:);
            if numel(pred) < 3
                pred = [pred, nan(1,3-numel(pred))];
            elseif numel(pred) > 3
                pred = pred(1:3);
            end
            % fprintf(fidw, '%s,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n', ...
                % tsStr, raw(1), raw(2), raw(3), raw(4), pred(1), pred(2), pred(3));
        end
        fclose(fidw);
    else
        warning('Failed to open logfile to flush remaining batch.');
    end
    st('batch') = {};
    st('timestamps') = {};
end
