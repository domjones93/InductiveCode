classdef Sensor < handle
    properties
        port
        baudrate = 115200
        timeout = 1
        ser = []
        net = []      % MATLAB network loaded from .mat (variable name `net`)
        % Device / calibration constants (adjust as required)
        % FREQUENCY_CONST = 1.0
        % CAPACITANCE = 1.0
        % INDUCTANCE_CONST = 1.0
                %% Constants
        INDUCTANCE_CONST = 25330.3387;
        FREQUENCY_CONST = 1.4901161249358807e-07;
        CAPACITANCE = 330.0;

    end

    methods
        function obj = Sensor(port, baudrate, timeout)
            if nargin >= 1 && ~isempty(port)
                obj.port = port;
            else
                obj.port = '';
            end
            if nargin >= 2 && ~isempty(baudrate)
                obj.baudrate = baudrate;
            end
            if nargin >= 3 && ~isempty(timeout)
                obj.timeout = timeout;
            end
        end

        function connect(obj)
            % Connect to the serial device using serialport
            if isempty(obj.port)
                error('No port specified. Construct with Sensor(port) or set obj.port.');
            end
            try
                % If an existing connection exists, clear it first
                if ~isempty(obj.ser)
                    try
                        clear obj.ser;
                    catch
                    end
                    obj.ser = [];
                end

                obj.ser = serialport(obj.port, obj.baudrate, 'Timeout', obj.timeout);
                % Attempt to flush buffers
                try
                    flush(obj.ser);
                catch
                end
                fprintf('Connected to serial port %s\n', obj.port);
            catch ME
                warning('Error connecting to serial port %s: %s', obj.port, ME.message);
                obj.ser = [];
            end
        end

        function data = read_single_measurement(obj)
            % Sends a single-measurement command and returns raw ASCII bytes as char
            if isempty(obj.ser)
                error('Serial connection is not established. Call connect() first.');
            end

            % Send single measurement command (single ASCII character 's')
            try
                write(obj.ser, uint8('s'), 'uint8');
            catch
                % fallback to writeline if write fails
                try
                    writeline(obj.ser, 's');
                catch
                end
            end

            pause(0.01); % allow device to respond (adjust if needed)

            n = obj.ser.NumBytesAvailable;
            if n <= 0
                error('No data received from the sensor.');
            end

            raw = read(obj.ser, n, 'uint8');
            % Interpret as ASCII characters
            data = char(raw(:)');
        end

        function [timestamp, status, L0, L1, L2, L3] = process_single_measurement(obj)
            % Read raw data stream and extract the first packet terminated by
            % the delimiter 'FFFEFD'. Returns timestamp, status and four L values.
            rawdata = obj.read_single_measurement();
            delimiter = 'FFFEFD';

            idx = strfind(rawdata, delimiter);
            if isempty(idx)
                error('Delimiter not found in received data.');
            end

            % Use the first packet before the delimiter
            raw_packet = rawdata(1:idx(1)-1);
            [timestamp, status, L0, L1, L2, L3] = obj.calibrate_packet(raw_packet);
        end

        function [timestamp, status, L0, L1, L2, L3] = calibrate_packet(obj, raw_bytes)
            % raw_bytes expected to be a char array of ASCII hex characters
            % Layout (Python indices):
            % 0:8   timestamp (8 chars)
            % 8:12  status (4 chars)
            % 12:20 Raw0 (8 chars)
            % 20:28 Raw1 (8 chars)
            % 28:36 Raw2 (8 chars)
            % 36:44 Raw3 (8 chars)

            % Ensure length
            if length(raw_bytes) < 44
                error('Packet too short: length %d', length(raw_bytes));
            end

            try
                ts_hex = raw_bytes(1:8);
                status_hex = raw_bytes(9:12);
                raw0_hex = raw_bytes(13:20);
                raw1_hex = raw_bytes(21:28);
                raw2_hex = raw_bytes(29:36);
                raw3_hex = raw_bytes(37:44);

                % Convert hex strings to numbers
                timestamp = double(hex2dec(ts_hex));
                status = double(hex2dec(status_hex));
                Raw0 = double(hex2dec(raw0_hex));
                Raw1 = double(hex2dec(raw1_hex));
                Raw2 = double(hex2dec(raw2_hex));
                Raw3 = double(hex2dec(raw3_hex));

                % Frequency and inductance conversion
                F0 = obj.FREQUENCY_CONST .* Raw0;
                F1 = obj.FREQUENCY_CONST .* Raw1;
                F2 = obj.FREQUENCY_CONST .* Raw2;
                F3 = obj.FREQUENCY_CONST .* Raw3

                L0 = obj.INDUCTANCE_CONST ./ (obj.CAPACITANCE .* (F0 .* F0));
                L1 = obj.INDUCTANCE_CONST ./ (obj.CAPACITANCE .* (F1 .* F1));
                L2 = obj.INDUCTANCE_CONST ./ (obj.CAPACITANCE .* (F2 .* F2));
                L3 = obj.INDUCTANCE_CONST ./ (obj.CAPACITANCE .* (F3 .* F3));
            catch ME
                error('Failed to parse packet: %s', ME.message);
            end
        end

        function load_calib_model(obj, model_path)
            % Load a .mat file expected to contain a variable named `net`.
            if ~isfile(model_path)
                error('Model file not found: %s', model_path);
            end
            S = load(model_path, 'net');
            if isfield(S, 'net')
                obj.net = S.net;
                fprintf('Calibration model loaded from %s\n', model_path);
            else
                error('No variable ''net'' found in %s', model_path);
            end
        end

        function predictions = predict_position(obj, inductance_values)
            % inductance_values: 1x4 or Nx4 numeric array
            if isempty(obj.net)
                error('Calibration network not loaded. Call load_calib_model first.');
            end
            if ~isnumeric(inductance_values)
                error('inductance_values must be numeric.');
            end

            % Ensure matrix shape: network then prediction
            % Try common network predict conventions
            try
                if ismatrix(inductance_values) && size(inductance_values,2) == 4
                    in = inductance_values'; % transpose to (features x samples) for many MATLAB nets
                else
                    in = inductance_values(:)';
                end
                % Use predict if available, otherwise try obj.net(in)
                if exist('predict','builtin') || exist('predict','file')
                    out = predict(obj.net, in);
                else
                    out = obj.net(in);
                end
                % Transpose back to samples x outputs
                predictions = out';
            catch ME
                error('Prediction failed: %s', ME.message);
            end
        end

        function disconnect(obj)
            if isempty(obj.ser)
                fprintf('No active serial connection to disconnect.\n');
                return;
            end
            try
                % Send exit command if device expects it
                try
                    write(obj.ser, uint8('x'), 'uint8');
                catch
                    try
                        writeline(obj.ser, 'x');
                    catch
                    end
                end
                pause(0.01);
                flush(obj.ser);
            catch
            end
            try
                clear obj.ser;
            catch
            end
            obj.ser = [];
            fprintf('Disconnected from serial port.\n');
        end
    end
end